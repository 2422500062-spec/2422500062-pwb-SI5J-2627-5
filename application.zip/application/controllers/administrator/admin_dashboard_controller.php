<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_dashboard_controller extends CI_Controller
{
    public function index {
        $data['title'] = 'Afdila Petshop';
        $this->load_>view('administrator/templates/header', $data);
        $this->load_>view('administrator/templates/sidebar', $data);
        $this->load_>view('administrator/templates/topbar', $data);
        $this->load_>view('administrator/dashboard', $data);
        $this->load_>view('administrator/templates/footer', $data);
    }
}
    
    